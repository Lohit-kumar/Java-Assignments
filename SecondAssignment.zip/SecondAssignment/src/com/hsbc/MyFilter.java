package com.hsbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;


@WebFilter(filterName="filterOne",urlPatterns = {"/Control.do"})
public class MyFilter implements Filter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		int flag=0;
		System.out.println("I am in Filter");
		PrintWriter out = response.getWriter();
		Map map = request.getParameterMap();
		for(Object key : map.keySet()){
		    String keyStr = (String)key;
		    String value = Arrays.toString((String[])map.get(keyStr)).replaceAll("[\\[\\],]","");
		    if(value.isEmpty()||value.trim().isEmpty()){
		    	flag=1;
		    	out.println("<font color='red'><b>"+(String)key+" is empty</b></font>");
                RequestDispatcher rd = request.getRequestDispatcher("Details.html");
                rd.include(request, response);
                //System.out.println("Key " + (String)key + " is empty    :    ");
                break;
		    }
		    
		    //System.out.println("Key " + (String)key + "     :    " + value);
		}
		if(flag==0){
			chain.doFilter(request,response);
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
