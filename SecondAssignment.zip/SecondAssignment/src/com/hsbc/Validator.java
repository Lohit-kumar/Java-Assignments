package com.hsbc;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {
	private static Pattern usrNamePtrn = Pattern.compile("[a-zA-Z]+(?: [a-zA-Z]+)*$");
	private static Pattern mobileNum = Pattern.compile("\\d{10}$");
    
    public static boolean validateUserName(String userName){
         
        Matcher mtch = usrNamePtrn.matcher(userName);
        if(mtch.matches()){
            return true;
        }
        return false;
    }
    public static boolean validateMobileNum(String mobNum){
        
        Matcher mtch = mobileNum.matcher(mobNum);
        if(mtch.matches()){
            return true;
        }
        return false;
    }


}
