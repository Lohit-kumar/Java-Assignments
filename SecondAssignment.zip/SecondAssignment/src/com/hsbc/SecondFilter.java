package com.hsbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter(filterName="secondFilter",urlPatterns = {"/Control.do"})
public class SecondFilter extends MyFilter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		int flag=0;
		System.out.println("I am in Second Filter");
		PrintWriter out = response.getWriter();
		Map map = request.getParameterMap();
		for(Object key : map.keySet()){
		    String keyStr = (String)key;
		    String value = Arrays.toString((String[])map.get(keyStr)).replaceAll("[\\[\\],]","");
		    if(keyStr.equals("Name")&&!(Validator.validateUserName(value))){
		    	flag=1;
		    	out.println("<font color='red'><b>"+(String)key+" is invalid. Name should start and end with letter. No special charchters or double whitespace are allowed.</b></font>");
                RequestDispatcher rd = request.getRequestDispatcher("Details.html");
                rd.include(request, response);
		       System.out.println("Key " + (String)key + "     :    " + value+" is  "+Validator.validateUserName(value));
		       break;}
		    if(keyStr.equals("MobileNo")&&!(Validator.validateMobileNum(value))){
		    	flag=1;		    	
		    	out.println("<font color='red'><b>"+(String)key+" is invalid. Mobile Number(only 10 digits) should start and end with number. No special charchters or whitespace are allowed.</b></font>");
                RequestDispatcher rds = request.getRequestDispatcher("Details.html");
                rds.include(request, response);
		       System.out.println("Key " + (String)key + "     :    " + value+" is  "+Validator.validateMobileNum(value));
		       break;}
		}
		if(flag==0){
		chain.doFilter(request,response);}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
