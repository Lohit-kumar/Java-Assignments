package com.hsbc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class reverseName {
	
	String reverse;
	public String reverseWords (String s) 
	{
	    List<String> words = Arrays.asList(s.split(" "));
	    Collections.rotate(words,1);
	    String str =words.toString();
	    return str.replaceAll("[\\[\\],]","").replaceFirst(" ", ", ");
	}

	public String getReverse() {
		return reverse;
	}

	public void setReverse(String reverse) {
		this.reverse =reverseWords(reverse) ;
	}
}
